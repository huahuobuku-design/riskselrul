# Local candidate release checklist

- [ ] Confirm final author names, affiliations, contributor roles, support contact, and software name.
- [ ] Review licensing/attribution before publishing. Apache-2.0 is the local candidate choice.
- [ ] Review the real validation report and known migration differences.
- [ ] Validate on another supported platform; current executed platform is recorded in run manifests.
- [ ] Review SoftwareX's current author guide/template, required metadata, software contribution, and reuse evidence.
- [ ] Create the intended repository, review the exact tracked file list, then publish an approved version.
- [ ] Archive an immutable release and fill citation/repository identifiers only after they exist.
- [ ] Prepare and approve the software article before submission.

The reference design's statement that SoftwareX does not assess originality is too broad. The official reviewer form asks for the software's contribution to research and its potential impact/reuse:
https://legacyfileshare.elsevier.com/promis_misc/softwarex-reviewer-form.pdf

The full current guide at https://www.sciencedirect.com/journal/softwarex/publish/guide-for-authors was not fully retrieved during this assembly. Exact word/page limits and mandatory template fields are therefore not represented here as verified. The current deliverable is a local alpha package, not a submission-ready or accepted article.
