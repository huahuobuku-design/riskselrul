"""Recalculate the supplied tables without running received Bot code or training."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
from riskselrul.audit import audit_run
from riskselrul import fixed_k_metrics

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    assert not args.out.exists(),'Choose a new output path'
    run=args.root/'grok_selected/repro_out'
    audit,_=audit_run(run)
    assert audit['mismatches']==0
    observed=pd.read_csv(run/'test_FD001_s42_st9001.csv')
    reference=pd.read_csv(args.root/'legacy_v0.2/paper/evidence/endpoint_predictions.csv')
    assert observed[['engine','scen']].equals(reference[['engine','scen']])
    comparisons={}
    for prefix in ['pred_','score_','acc_','sel80_']:
        cols=[c for c in reference if c.startswith(prefix)]
        x,y=observed[cols].to_numpy(),reference[cols].to_numpy()
        comparisons[prefix]={'values':int(x.size),'exact_equal':bool(np.array_equal(x,y)),'max_abs_difference':float(np.max(np.abs(x-y)))}
        assert np.array_equal(x,y)
    example=json.loads((args.root/'grok_selected/check_metrics_output.json').read_text())
    inputs=example['inputs']
    for k in range(9):
        got=fixed_k_metrics(inputs['pred'],inputs['target'],inputs['score'],k,inputs['ids'])
        expected=example['checks'][f'fixed_k_{k}']
        assert got['selected_indices']==expected['api_selected']
        assert got['retained']['mse']==expected['api_retained_mse']
    result={'scope':'Arithmetic and received table comparison only; no training or independent proof of execution history', 'audit':audit,'comparisons':comparisons,'received_numeric_check_entries':len(example['checks'])}
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
