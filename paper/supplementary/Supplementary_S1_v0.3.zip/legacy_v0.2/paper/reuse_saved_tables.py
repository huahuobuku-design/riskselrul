"""Executable article example using the installed NumPy-only public API.

Run outside the software source directory after installing the supplied wheel:
python reuse_saved_tables.py --out reuse_check.json
No model fitting, plotting, network access, or training dependencies.
"""
import argparse
import csv
import json
from pathlib import Path

import numpy as np
from riskselrul import fixed_k_metrics
from riskselrul.metrics import prediction_metrics, risk_coverage_curve

HERE = Path(__file__).resolve().parent


def read(path):
    with path.open(encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    rows = read(HERE / "evidence/endpoint_predictions.csv")
    expected = read(HERE / "figures/all_metrics.csv")
    curves = read(HERE / "figures/all_curves_ridge_clean_H_log.csv")
    checks = 0
    for exp in expected:
        scen, pred, head = exp["scenario"], exp["predictor"], exp["head"]
        cell = [r for r in rows if r["scen"] == scen]
        p = np.array([float(r["pred_" + pred]) for r in cell])
        y = np.array([float(r["y_raw"]) for r in cell])
        score = np.array([float(r[f"score_{pred}_{head}"]) for r in cell])
        ids = [r["engine"] for r in cell]
        result = fixed_k_metrics(p, y, score, k=80, sample_ids=ids)
        for value, name in [(result["retained"]["mse"], "k80_mse"),
                            (result["oracle"]["mse"], "k80_oracle_mse"),
                            (result["random_expected_mse"], "random_expected_mse")]:
            if not np.isclose(value, float(exp[name]), rtol=1e-12, atol=1e-9):
                raise ValueError("Public API differs from independent article table")
            checks += 1
        accepted = np.array([int(r[f"acc_{pred}_{head}"]) for r in cell], dtype=bool)
        retained = prediction_metrics(p[accepted], y[accepted])
        if retained["mse"] is None:
            if exp["threshold_mse"] != "":
                raise ValueError("Missing-value mismatch")
        elif not np.isclose(retained["mse"], float(exp["threshold_mse"]), rtol=1e-12, atol=1e-9):
            raise ValueError("Threshold metric mismatch")
        checks += 1
        if pred == "ridge_clean" and head == "H_log":
            curve = risk_coverage_curve(p, y, score, ids)
            ref_curve = [r for r in curves if r["scenario"] == scen]
            for got, saved in zip(curve, ref_curve):
                for name in ("k", "acceptance_rate", "retained_mse", "oracle_mse", "random_expected_mse"):
                    if not np.isclose(got[name], float(saved[name]), rtol=1e-12, atol=1e-9):
                        raise ValueError("Public curve differs from article curve")
                    checks += 1
    report = dict(status="PASS", scope="Installed public NumPy API on saved real simulation-derived predictions; no training",
                  metric_cells=len(expected), curve_points=len(curves), numeric_checks=checks, mismatches=0)
    with Path(args.out).open("x", encoding="utf-8") as f:
        json.dump(report, f, indent=2, allow_nan=False)
        f.write("\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
