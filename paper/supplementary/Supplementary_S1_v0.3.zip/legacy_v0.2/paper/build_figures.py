"""Recompute article numbers and figures from saved numeric evidence; never fit a model.

Run: python build_figures.py --out generated
Requires NumPy and Matplotlib. Input paths are relative to this script.
Use a fresh output directory; no overwrite. No network or object deserialization.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import platform
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    with path.open("x", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def json_write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    out = Path(args.out).resolve()
    if out.exists():
        raise ValueError("Choose a fresh output directory")
    out.mkdir(parents=True)
    data = HERE / "evidence"
    manifest = json.loads((data / "provenance.json").read_text(encoding="utf-8"))
    for name, expected in manifest["staged_hashes"].items():
        if digest(data / name) != expected:
            raise ValueError("Input hash mismatch: " + name)
    rows = read_csv(data / "endpoint_predictions.csv")
    reference = read_csv(data / "reference_metrics.csv")
    thresholds = json.loads((data / "thresholds.json").read_text(encoding="utf-8"))
    scenarios = list(dict.fromkeys(r["scen"] for r in rows))
    if len(rows) != 2100 or len(scenarios) != 21:
        raise ValueError("Expected one saved FD001 case: 100 engines x 21 scenarios")
    predictors = ["ridge_clean", "ridge_aug", "hgb_clean", "hgb_aug"]
    heads = ["H_log", "H_sq", "pred_only", "fault_indicator"]
    summary, curves, checks = [], [], 0
    reference_by = {(r["pred"], r["head"], r["scen"]): r for r in reference}
    for scen in scenarios:
        cell = [r for r in rows if r["scen"] == scen]
        if len(cell) != 100 or len({r["engine"] for r in cell}) != 100:
            raise ValueError("Endpoint rows must contain exactly one row per engine")
        y = np.array([float(r["y_raw"]) for r in cell])
        keys = np.array([hashlib.sha256(r["engine"].encode()).hexdigest() for r in cell])
        for pred in predictors:
            e2 = (np.array([float(r["pred_" + pred]) for r in cell]) - y) ** 2
            for head in heads:
                s = np.array([float(r[f"score_{pred}_{head}"]) for r in cell])
                # Numeric data only. Targets do not enter the selected order.
                order = np.lexsort((np.arange(100), keys, s))
                saved_fixed = np.array([int(r[f"sel80_{pred}_{head}"]) for r in cell], dtype=bool)
                fixed = np.zeros(100, dtype=bool)
                fixed[order[:80]] = True
                acc = s <= thresholds[pred][head]
                saved_acc = np.array([int(r[f"acc_{pred}_{head}"]) for r in cell], dtype=bool)
                if not np.array_equal(fixed, saved_fixed) or not np.array_equal(acc, saved_acc):
                    raise ValueError("Saved decision mismatch: " + str((scen, pred, head)))
                checks += 200
                k = int(acc.sum())
                retained = float(e2[acc].mean()) if k else None
                result = dict(scenario=scen, predictor=pred, head=head, n=100,
                              full_mse=float(e2.mean()), full_rmse=float(np.sqrt(e2.mean())),
                              threshold_n=k, acceptance_rate=k / 100,
                              threshold_mse=retained,
                              threshold_rmse=None if k == 0 else float(np.sqrt(retained)),
                              k80_mse=float(e2[order[:80]].mean()),
                              k80_oracle_mse=float(np.sort(e2)[:80].mean()),
                              random_expected_mse=float(e2.mean()))
                ref = reference_by[(pred, head, scen)]
                for new, old in [("full_mse", "full.MSE"), ("full_rmse", "full.RMSE"),
                                 ("threshold_n", "thr.k"), ("acceptance_rate", "thr.ratio"),
                                 ("threshold_mse", "thr.ret_MSE"), ("k80_mse", "k80.sel.MSE"),
                                 ("k80_oracle_mse", "k80.oracle.MSE")]:
                    a, b = result[new], ref[old]
                    if a is None:
                        if b not in ("", "nan", "NaN"):
                            raise ValueError("Empty-retention reference mismatch")
                    elif not np.isclose(a, float(b), rtol=1e-12, atol=1e-9):
                        raise ValueError("Reference metric mismatch: " + new)
                    checks += 1
                summary.append(result)
                if pred == "ridge_clean" and head == "H_log":
                    ranks = np.arange(1, 101)
                    selected_mse = np.cumsum(e2[order]) / ranks
                    oracle_mse = np.cumsum(np.sort(e2)) / ranks
                    for kk, m, o in zip(ranks, selected_mse, oracle_mse):
                        curves.append(dict(scenario=scen, k=int(kk), acceptance_rate=float(kk / 100),
                                           retained_mse=float(m), oracle_mse=float(o),
                                           random_expected_mse=float(e2.mean())))
    write_csv(out / "all_metrics.csv", summary)
    write_csv(out / "all_curves_ridge_clean_H_log.csv", curves)
    focal = [r for r in summary if r["predictor"] == "ridge_clean" and r["head"] == "H_log"]
    write_csv(out / "all_scenarios_ridge_clean_H_log.csv", focal)
    plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                         "pdf.fonttype": 42, "ps.fonttype": 42, "svg.hashsalt": "riskselrul-paper-v1"})

    def save(fig, name):
        for ext in ("svg", "pdf", "png"):
            fig.savefig(out / (name + "." + ext), dpi=180, bbox_inches="tight")
        plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 4.7))
    ax.set(xlim=(0, 10), ylim=(0, 5))
    ax.axis("off")
    boxes = [(0.1, 3.3, 2.0, 1.15, "User-supplied NASA files\ninspect-data / extract-data"),
             (2.65, 3.3, 3.0, 1.15, "WP05A raw-data profile: reproduce\nEngine splits + fold-local preprocessing\nOOF risk heads + calibration + faults"),
             (6.2, 3.3, 3.6, 1.15, "Numeric experiment evidence\nConfig / hashes / fit boundaries\nPredictions / decisions / logs / exit code"),
             (6.2, 1.65, 3.6, 1.0, "audit / curve\nIndependent arithmetic + fixed-k diagnostics\nNo fitting; oracle is retrospective"),
             (0.1, 0.1, 3.9, 1.05, "Separate WP04A archived-state profile\n78 numeric states + raw (n, 30, 21) windows"),
             (4.6, 0.1, 5.2, 1.05, "NumPy-only predict\nPoint prediction + risk score + frozen-threshold decision\nNot regenerated by the WP05A training command")]
    for x, y, w, h, label in boxes:
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.04", facecolor="#eef3f8", edgecolor="#366588"))
        ax.text(x + w / 2, y + h / 2, label, ha="center", va="center", fontsize=8)
    for a, b in [((2.15, 3.88), (2.6, 3.88)), ((5.7, 3.88), (6.15, 3.88)),
                 ((8, 3.25), (8, 2.7)), ((4.05, 0.63), (4.55, 0.63))]:
        ax.annotate("", xy=b, xytext=a, arrowprops=dict(arrowstyle="->", color="#366588", lw=1.5))
    ax.text(.1, 2.25, "Two versioned profiles with separate lineage", fontsize=11, fontweight="bold")
    save(fig, "figure1_architecture")

    selected_scenarios = ["clean", "A_bias+4", "B_bias+4"]
    fig, axes = plt.subplots(1, 3, figsize=(10, 3.15))
    for ax, scen in zip(axes, selected_scenarios):
        cc = [r for r in curves if r["scenario"] == scen]
        x = [r["acceptance_rate"] for r in cc]
        ax.plot(x, [r["retained_mse"] for r in cc], label="H_log ranking", color="#276b99")
        ax.plot(x, [r["oracle_mse"] for r in cc], label="Label-informed oracle", color="#51955d", ls="--")
        ax.axhline(cc[0]["random_expected_mse"], label="Uniform random: expected MSE", color="#555555", ls=":")
        ax.axvline(.8, color="#bbb", lw=.7)
        ax.set(title=scen, xlabel="Retained fraction (offline)", ylabel="Mean squared error (cycles²)", xlim=(0, 1))
        ax.grid(alpha=.18)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, fontsize=7, loc="lower center", ncol=3, bbox_to_anchor=(.5, -.03))
    fig.suptitle("One reproduced FD001 case: seed 42, fault stream 9001; fixed ridge_clean predictor", fontsize=10)
    fig.tight_layout(rect=(0, .06, 1, 1))
    save(fig, "figure2_ranking_diagnostics")

    fig, axes = plt.subplots(1, 2, figsize=(10, 6), sharey=True)
    ys = np.arange(len(focal))
    axes[0].barh(ys, [r["acceptance_rate"] for r in focal], color="#276b99")
    axes[0].axvline(.8, color="#c25436", ls="--", label="Calibration target 0.8")
    axes[0].set(xlim=(0, 1.04), xlabel="Frozen-threshold acceptance", yticks=ys, yticklabels=[r["scenario"] for r in focal])
    axes[0].invert_yaxis()
    axes[0].legend(fontsize=7, loc="lower right")
    ratios = [r["k80_mse"] / r["full_mse"] for r in focal]
    axes[1].barh(ys, ratios, color=["#c25436" if r > 1 else "#51955d" for r in ratios])
    axes[1].axvline(1, color="#555", ls="--")
    axes[1].set(xlabel="k=80 MSE / full MSE\n<1: better than expected uniform random retention")
    for ax in axes:
        ax.grid(axis="x", alpha=.15)
    fig.suptitle("All 21 scenarios, same FD001 case and ridge_clean / H_log; different diagnostics", fontsize=10)
    fig.tight_layout()
    save(fig, "figure3_acceptance_and_ranking")
    report = dict(status="PASS", scope="Saved-table recomputation only; no model fitting or new timing",
                  rows=2100, metric_cells=len(summary), scalar_and_decision_checks=checks, mismatches=0,
                  figure_focus="Fixed ridge_clean/H_log example, not a selected best model",
                  python=sys.version, platform=platform.platform(), numpy=np.__version__, matplotlib=matplotlib.__version__,
                  inputs=manifest["staged_hashes"], script_sha256=digest(Path(__file__)),
                  illustrative_rows=[r for r in focal if r["scenario"] in selected_scenarios],
                  all_scenarios_acceptance_range=[min(r["acceptance_rate"] for r in focal), max(r["acceptance_rate"] for r in focal)])
    json_write(out / "figure_validation.json", report)
    json_write(out / "output_hashes.json", {p.name: digest(p) for p in sorted(out.iterdir()) if p.is_file()})
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
