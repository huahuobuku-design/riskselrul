# Supplementary S1, revision 0.3

This material supports a software article, not a new algorithm or physical-engine experiment. `legacy_v0.2/` preserves prior derived numerical evidence and plotting code unchanged. `grok_selected/` contains selected returned calibration/prediction/metric tables and short training logs; full Bot environment/coordination and machine-identifying logs are excluded. These table checks do not independently prove every execution event or upstream absence of leakage.

Install the validated 0.1.0 wheel with training dependencies (or clone its explicit Git tag and install `.[train]`). Run `python recheck_s1.py --out NEW_REPORT.json` to recalculate 5,392 arithmetic checks and compare predictions/decisions with the earlier Windows reference. No received Bot scripts execute, no training occurs and no raw NASA data are needed. `python quickstart_arrays.py --out NEW_DIRECTORY` runs the synthetic eight-row API demonstration using NumPy alone.

The original failed Bot invocation of example 01 without required arguments returned exit 2; it is not a successful training test. Actual returned numeric JSON contains 14 check entries, not 15. CI covers installation/tests/CLI and the synthetic example, not full raw-data fitting. AI-operated Debian verification is not external human adoption.

For the prior saved-result plots/API checks, enter `legacy_v0.2/` and follow its README. The old three-figure outputs are historical supplements; the current article embeds two figures. Original NASA data and external code/paper PDFs are not redistributed. Software/data archive DOI: —. A public GitHub release is not an immutable archival deposit.
