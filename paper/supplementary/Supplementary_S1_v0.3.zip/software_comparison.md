# 同类软件及已发表软件论文对照

核查日期：2026-10-17。只比较已公开可核查的出版物和软件；他人未公开的投稿稿件不可获得，不冒充读过。

## 接口范围对照

| 对象 | 实际读取的主来源 | 可核实的功能定位 | 与本软件的关系 / 结论边界 |
| --- | --- | --- | --- |
| CeRULEo | JOSS 2023 正式论文全文，DOI 10.21105/joss.05294；源码 commit `1ad630c0cfcbe23f7dd184e5abbefe8e0a0cb1fc` 的 results 模块及 graphics 检索 | RUL 数据准备、特征工程、训练、预测结果与交叉验证、维护相关指标 | 可以提供预测数组。检查的 results/graphics 范围未识别到我们描述的整套 threshold/fixed-k 核算；不推断整个项目绝无类似组合，也不声称其不能扩展。 |
| NASA ProgPy | NASA 官方项目、文档 API；commit `7c2688a44603ccb0c0994e51d611e931d3695ac0` 的 metrics 包 | 模型、仿真、状态估计、预测与不确定性传播，以及时间到事件等指标 | 不是单纯物理模型工具，含数据驱动扩展。检查的 metrics/API 中未识别该整套核算流程；不等于穷尽所有扩展。 |
| MAPIE | 当前官方文档、API 目录；Cordier 等 COPA/PMLR 2023 正式论文页 | 共形回归/分类、风险控制、校准和分布假设相关工具 | 不能说 MAPIE 没有拒判或风险控制，当前文档明确含相关功能。我们的区别是固定数组和指定接受条件的核算及特定故障工作流，不能借它的理论保证。未做运行速度/预测精度对比。 |
| SelectiveNet 公开实现 | 作者 GitHub README 与 ICML 2019 正式论文页 | 联合训练预测与选择；代码示例列 CIFAR-10、CatsDogs、SVHN | 作者论文讨论分类/回归，不能把当前示例集等同全部理论范围。是选择方法实现，不是我们固定基准的替代说明。未执行作者训练代码。 |
| Uncertainty Toolbox | 作者 ICML 2021 workshop 论文全文、公开项目 | 校准、sharpness、proper scores、再校准、可视化 | 同样提供可复用评估，因此不能把“数组指标接口”本身称首创。我们的具体用途是显式记录接受数量、条件与误差，并接入一个可重跑的故障基准。 |

上述源码检查仅做静态阅读，没有安装或执行第三方代码。检索词为 abstain/reject/risk.coverage/fixed-k 等，未命中只能支持该检索范围内的观察，不能证明功能不存在。没有将第三方仓库代码打入我们的发行版或论文包。

## 已发表软件论文的呈现方式

| 论文 | 状态与读取程度 | 可借鉴之处 | 不能据此推出 |
| --- | --- | --- | --- |
| UTypes: A library for uncertain datatypes in Python, SoftwareX 26 (2024) 101676, DOI 10.1016/j.softx.2024.101676 | 出版社索引可见摘要、代码元数据及功能描述。直接全文访问出现 403/人机验证，未绕过，全文未知。 | 明确输入类型、支持操作、用户接口和软件版本，贡献可以是有边界的库功能。 | 不能声称已完整读其 Impact，也不能据此认定我们的证据与其等强。 |
| UQpy v4.1: Uncertainty quantification with Python, SoftwareX (2023), DOI 10.1016/j.softx.2023.101561 | 作者机构库记录、官方项目文档核验；本文未完成全文逐节阅读。 | 展示模块/API 和具体研究用途；可复用工具不必改写为单一预测精度竞赛。 | 不复制其广泛适用性或用户基础，也不把它的模型能力算到本包。 |
| CeRULEo, JOSS 8(88) (2023) 5294 | 正式全文已读，发表于 2023-08-10。不是 SoftwareX。 | 从具体用户需求进入软件功能；列出数据流、特征、模型及结果接口，最适合我们的领域软件对照。 | 不把 JOSS 模板或审稿条件混当 SoftwareX 的硬要求。 |

## 对本稿的实际修改

正文从“发现评估陷阱”改为“记录和复现接受条件的工具”；先展示无 NASA 数据的 8 行数组例子，再展示真实保存的仿真预测表。固定的 C-MAPSS 训练命令是应用示例，不称通用训练框架。审计细节与失败日志留 S1；正文仅保留必要验证结论。外部用户采用、作者和 DOI 没有证据时用“—”，不从 CI 或 Bot 复测推导社会影响力。

## 主来源链接

- CeRULEo 正式论文：https://joss.theoj.org/papers/10.21105/joss.05294
- CeRULEo 公开代码：https://github.com/lucianolorenti/ceruleo
- ProgPy 官方代码：https://github.com/nasa/progpy
- ProgPy API：https://nasa.github.io/progpy/api_ref/progpy.html
- MAPIE 当前文档：https://mapie.readthedocs.io/en/stable/
- MAPIE 正式论文：https://proceedings.mlr.press/v204/cordier23a.html
- SelectiveNet：https://proceedings.mlr.press/v97/geifman19a.html ，https://github.com/geifmany/selectivenet
- Uncertainty Toolbox 作者全文：https://www.gatsby.ucl.ac.uk/~balaji/udl2021/accepted-papers/UDL2021-paper-018.pdf
- UTypes 出版社记录：https://www.sciencedirect.com/science/article/pii/S2352711024000475
- UQpy 作者机构库：https://escholarship.org/uc/item/6sn772v0
