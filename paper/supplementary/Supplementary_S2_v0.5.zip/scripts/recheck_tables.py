"""Local review of delivered data; does not execute Bot scripts or fit models."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import numpy as np
import pandas as pd
from riskselrul.audit import audit_run

HERE = Path(__file__).resolve().parents[1] / "verification"
DATA = HERE.parent / "expanded"
def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
checks = 0
failures = []
def compare(label, actual, expected):
    global checks
    checks += 1
    if not np.allclose(actual, expected, rtol=1e-9, atol=1e-9, equal_nan=True):
        failures.append(label)
manifest = read(DATA / "MANIFEST_files.json")
for item in manifest:
    path = DATA / item["path"]
    assert path.is_file() and path.stat().st_size == item["bytes"], item["path"]
    assert digest(path) == item["sha256"], item["path"]
expected_freeze = read(HERE / "expected_freeze.json")
for name, field in [("PROTOCOL.md", "protocol_sha256"), ("config.json", "config_sha256")]:
    assert digest(DATA/name) == expected_freeze[field]
logs = [read(p) for p in sorted((DATA/"logs").glob("*.json")) if "exit_code" in read(p)]
audits = {}
for run in sorted((DATA/"out/A").iterdir()):
    report, _ = audit_run(run)
    audits[run.name] = report
    assert report["checked"] == 16176 and report["mismatches"] == 0, run.name

# Independent formulas: all B point estimates, computed from exported terminal rows.
B = pd.read_csv(DATA/"out/B/B_per_combination.csv", float_precision="round_trip")
keys = ["dataset", "seed", "stream", "scenario", "predictor", "head", "target", "mode"]
indexed = B.set_index(keys, verify_integrity=True)
visited = 0
for path in sorted((DATA/"out/A").glob("*/test_*_st*.csv")):
    ds, seed, stream = path.stem[5:].split("_")
    seed, stream = int(seed[1:]), int(stream[2:])
    table = pd.read_csv(path, float_precision="round_trip")
    predictors = [c[5:] for c in table if c.startswith("pred_")]
    for scenario, frame in table.groupby("scen", sort=False):
        frame = frame.sort_values("engine", key=lambda x: x.str.split(":").str[1].astype(int))
        n = len(frame)
        ids = frame.engine.to_numpy()
        hashes = np.array([hashlib.sha256(v.encode()).hexdigest() for v in ids])
        for predictor in predictors:
            prediction = frame[f"pred_{predictor}"].to_numpy()
            for head in ("H_log", "H_sq", "pred_only", "fault_indicator"):
                score = frame[f"score_{predictor}_{head}"].to_numpy()
                order = np.lexsort((np.arange(n), hashes, score))
                for target_mode in ("uncapped", "cap125"):
                    target = frame.y_raw.to_numpy()
                    if target_mode == "cap125":
                        target = np.minimum(target, 125)
                    error = prediction - target
                    squared = error**2
                    score08 = np.empty(n)
                    neg = error < 0
                    score08[neg] = np.expm1(-error[neg]/13)
                    score08[~neg] = np.expm1(error[~neg]/10)
                    rank_risk = np.mean(np.cumsum(squared[order])/np.arange(1,n+1))
                    oracle = np.mean(np.cumsum(np.sort(squared))/np.arange(1,n+1))
                    for mode, flag in [("full", np.ones(n,dtype=bool)),
                        ("threshold", frame[f"acc_{predictor}_{head}"].to_numpy().astype(bool)),
                        ("fixed_k80", frame[f"sel80_{predictor}_{head}"].to_numpy().astype(bool))]:
                        key = (ds,seed,stream,scenario,predictor,head,target_mode,mode)
                        row = indexed.loc[key]
                        k = int(flag.sum())
                        values = dict(n=n,n_accepted=k,acceptance_ratio=k/n,
                            aurc_mse=rank_risk,oracle_aurc_mse_posthoc=oracle,
                            random_expected_mse=squared.mean(),
                            rmse=np.sqrt(squared[flag].mean()) if k else np.nan,
                            mse=squared[flag].mean() if k else np.nan,
                            mae=np.abs(error[flag]).mean() if k else np.nan,
                            overest_gt20_rate=np.mean(error[flag]>20) if k else np.nan,
                            phm08_sum=score08[flag].sum(),
                            phm08_mean_per_accepted=score08[flag].mean() if k else np.nan)
                        for metric, value in values.items():
                            compare(str(key)+metric, row[metric], value)
                        visited += 1
assert visited == len(B)
# Confirm equal weighting of point estimates separately from bootstrap intervals.
groupkeys = ["dataset","predictor","head","scenario","target","mode"]
metrics = ["n_accepted","acceptance_ratio","rmse","mae","mse","overest_gt20_rate",
    "phm08_sum","phm08_mean_per_accepted","aurc_mse","oracle_aurc_mse_posthoc","random_expected_mse"]
avg = pd.read_csv(DATA/"out/B/B_equal_average.csv",float_precision="round_trip").set_index(groupkeys)
reavg = B.groupby(groupkeys)[metrics].mean()
for metric in metrics:
    compare("B_equal_average_"+metric,avg.loc[reavg.index,metric],reavg[metric])

# Recalculate non-RUL example thresholds and statistics from exported rows.
C = read(DATA/"out/C/summary_C.json")
for run in C["runs"]:
    tag = f'{run["dataset"]}_s{run["seed"]}'
    cal = pd.read_csv(DATA/f"out/C/cal_{tag}.csv",float_precision="round_trip")
    test = pd.read_csv(DATA/f"out/C/test_{tag}.csv",float_precision="round_trip")
    oof = pd.read_csv(DATA/f"out/C/oof_{tag}.csv",float_precision="round_trip")
    records = read(DATA/f"out/C/records_{tag}.json")
    fitids,calids,testids = [set(records["split"][s]) for s in ("fit","cal","test")]
    assert not (fitids & calids or fitids & testids or calids & testids)
    assert set(oof.id)==fitids and set(cal.id)==calids and set(test.id)==testids
    heldout=[]
    for fold in records["folds"]:
        a,b=set(fold["train_ids"]),set(fold["val_ids"])
        assert not a&b and a|b==fitids
        heldout.extend(b)
    assert len(heldout)==len(fitids) and set(heldout)==fitids
    compare(tag+"oof_target",oof.oof_log1p_absres,np.log1p(np.abs(oof.y_true-oof.oof_pred)))
    e=test.pred.to_numpy()-test.y_true.to_numpy(); e2=e**2; n=len(e); k=run["fixed_k"]
    hashids=np.array([hashlib.sha256(v.encode()).hexdigest() for v in test.id])
    for head in ("risk_head","random","prediction_only"):
        s=test[f"score_{head}"].to_numpy()
        q=np.quantile(cal[f"score_{head}"],.8)
        compare(tag+head+"quantile",run["thresholds"][head],q)
        flag=s<=q
        compare(tag+head+"acceptance",test[f"acc_{head}"],flag)
        order=np.lexsort((np.arange(n),hashids,s))
        result=run["results"][head]
        for metric,value in dict(n_accepted=flag.sum(),acceptance_ratio=flag.mean(),
            mse=e2[flag].mean(),rmse=np.sqrt(e2[flag].mean())).items():
            compare(tag+head+"threshold_"+metric,result["threshold"][metric],value)
        for metric,value in dict(n_accepted=k,mse=e2[order[:k]].mean(),
            rmse=np.sqrt(e2[order[:k]].mean()),oracle_mse_posthoc=np.sort(e2)[:k].mean(),
            random_expected_mse=e2.mean()).items():
            compare(tag+head+"fixedk_"+metric,result["fixed_k"][metric],value)
        compare(tag+head+"aurc",result["aurc_mse"],np.mean(np.cumsum(e2[order])/np.arange(1,n+1)))
    compare(tag+"oracle_aurc",run["results"]["oracle_offline"]["aurc_mse"],
        np.mean(np.cumsum(np.sort(e2))/np.arange(1,n+1)))
report=dict(verified_at=datetime.now(timezone.utc).isoformat(),
    manifest_files_verified=len(manifest),protocol_and_config_match_presend_hashes=True,
    command_logs=[dict(name=r["name"],exit_code=r["exit_code"],elapsed_s=r["elapsed_s"])
        for r in logs],trusted_local_audits=audits,independent_scalar_or_array_checks=checks,
    mismatches=len(failures),failures=failures,B_rows_recomputed=visited,
    C_runs_recomputed=len(C["runs"]),C_split_fold_id_checks_passed=True,
    scope="Received-table recomputation and log inspection, not fresh model fitting; B bootstrap intervals and C preprocessing statistics not independently rerun yet.")
(HERE/"initial_numeric_review.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({k:v for k,v in report.items() if k not in ("command_logs","trusted_local_audits")},ensure_ascii=False,indent=2))
assert not failures
