from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/"S2_manifest.json").read_text(encoding="utf-8-sig"))
for r in manifest:
    p=root/r["path"]
    assert p.is_file() and p.stat().st_size==r["bytes"],r["path"]
    assert hashlib.sha256(p.read_bytes()).hexdigest()==r["sha256"],r["path"]
print(f"Verified {len(manifest)} files")
