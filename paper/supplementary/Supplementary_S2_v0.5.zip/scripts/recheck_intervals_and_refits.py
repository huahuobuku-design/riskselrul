"""Independent interval reconstruction, non-RUL refits and raw-data boundary review.

Reads received numeric files, never imports received scripts. Writes only local reviews.
"""
import os
for name in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[name]="1"
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import numpy as np
import pandas as pd
from sklearn.datasets import load_diabetes, make_friedman1
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.model_selection import KFold
from threadpoolctl import threadpool_limits

HERE=Path(__file__).resolve().parents[1]/"verification"
PROJECT=HERE.parents[2]
DATA=HERE.parent/"expanded"
def read(p): return json.loads(p.read_text(encoding="utf-8-sig"))
failures=[]; checks=0; maxdiff={}; maxrelative={}
def check(label,a,b,rtol=1e-8,atol=1e-8):
    global checks
    checks+=1
    a,b=np.asarray(a),np.asarray(b)
    if a.shape!=b.shape or not np.allclose(a,b,rtol=rtol,atol=atol,equal_nan=True): failures.append(label)
    if a.shape==b.shape and a.size:
        d=float(np.nanmax(np.abs(a-b)))
        section=label.split(":")[0]
        maxdiff[section]=max(maxdiff.get(section,0),d)
        relative=float(np.nanmax(np.abs(a-b)/np.maximum(1,np.abs(b))))
        maxrelative[section]=max(maxrelative.get(section,0),relative)

# Refit independent elementary Ridge workflows on the actual builtin datasets.
dataset=load_diabetes(scaled=False)
datasets={"diabetes_real":(dataset.data,dataset.target),
    "friedman1_SYNTHETIC":make_friedman1(n_samples=1000,n_features=10,noise=1.,random_state=20261017)}
C_results=[]
with threadpool_limits(1):
    for name,(X,y) in datasets.items():
        for seed in (42,43,44):
            tag=f"{name}_s{seed}"
            rec=read(DATA/f"out/C/records_{tag}.json")
            nf,nc=round(.6*len(y)),round(.2*len(y))
            perm=np.random.default_rng(seed).permutation(len(y))
            fit,cal,test=perm[:nf],perm[nf:nf+nc],perm[nf+nc:]
            for s,ix in [("fit",fit),("cal",cal),("test",test)]:
                assert rec["split"][s]==[f"{name}_{i}" for i in ix]
            oof=np.empty(nf)
            for j,(tr,va) in enumerate(KFold(5,shuffle=True,random_state=seed).split(fit)):
                sc=StandardScaler().fit(X[fit[tr]])
                m=Ridge(alpha=1).fit(sc.transform(X[fit[tr]]),y[fit[tr]])
                oof[va]=m.predict(sc.transform(X[fit[va]]))
                r=rec["folds"][j]
                assert r["train_ids"]==[f"{name}_{i}" for i in fit[tr]]
                assert r["val_ids"]==[f"{name}_{i}" for i in fit[va]]
                check("C_fold_mean:"+tag+str(j),sc.mean_,r["scaler_mean"])
                check("C_fold_scale:"+tag+str(j),sc.scale_,r["scaler_scale"])
            ot=pd.read_csv(DATA/f"out/C/oof_{tag}.csv",float_precision="round_trip")
            check("C_oof_prediction:"+tag,oof,ot.oof_pred)
            check("C_fit_labels:"+tag,y[fit],ot.y_true)
            ms=StandardScaler().fit(X[fit]); main=Ridge(alpha=1).fit(ms.transform(X[fit]),y[fit])
            Z=np.column_stack((X[fit],oof)); rs=StandardScaler().fit(Z)
            risk=Ridge(alpha=1).fit(rs.transform(Z),np.log1p(np.abs(y[fit]-oof)))
            for prefix,s,m in [("main",ms,main),("risk",rs,risk)]:
                check("C_model_scaler_mean:"+tag+prefix,s.mean_,rec[prefix+"_scaler"]["mean"])
                check("C_model_scaler_scale:"+tag+prefix,s.scale_,rec[prefix+"_scaler"]["scale"])
                check("C_model_coef:"+tag+prefix,m.coef_,rec[prefix+"_coef"])
                check("C_model_intercept:"+tag+prefix,m.intercept_,rec[prefix+"_intercept"])
            g=np.random.default_rng(seed+10000)
            for split,ix in [("cal",cal),("test",test)]:
                t=pd.read_csv(DATA/f"out/C/{split}_{tag}.csv",float_precision="round_trip")
                p=main.predict(ms.transform(X[ix]))
                score=risk.predict(rs.transform(np.column_stack((X[ix],p))))
                check("C_pred:"+tag+split,p,t.pred)
                check("C_target:"+tag+split,y[ix],t.y_true)
                check("C_risk_score:"+tag+split,score,t.score_risk_head)
                check("C_random_score:"+tag+split,g.random(len(ix)),t.score_random)
                check("C_predonly_score:"+tag+split,p,t.score_prediction_only)
            C_results.append(dict(dataset=name,seed=seed,status="independent_refit_compared"))
print("C independent refits completed",flush=True)

# Raw training files: independently reconstruct sensor and feature moments by fold.
import argparse
parser=argparse.ArgumentParser()
parser.add_argument("--raw-data",required=True,type=Path)
raw=parser.parse_args().raw_data
cols=["unit","cycle","op1","op2","op3"]+[f"s{i}" for i in range(1,22)]
sensors=["s2","s3","s4","s7","s8","s9","s11","s12","s13","s14","s15","s17","s20","s21"]
raw_hashes={}; boundary_rows=[]; raw_shapes={}
expected_data=read(DATA/"config.json")["data"]["expected_sha256"]
for ds in ("FD001","FD003"):
    train=pd.read_csv(raw/f"train_{ds}.txt",sep=r"\s+",header=None,names=cols)
    terminal=pd.read_csv(raw/f"test_{ds}.txt",sep=r"\s+",header=None,names=cols)
    rul=np.loadtxt(raw/f"RUL_{ds}.txt")
    for kind in ("train","test","RUL"):
        p=raw/f"{kind}_{ds}.txt"; raw_hashes[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
        assert raw_hashes[p.name]==expected_data[p.name]
    assert train.shape[1]==terminal.shape[1]==26 and len(rul)==100
    assert train.unit.nunique()==terminal.unit.nunique()==100
    raw_shapes[ds]=dict(train=list(train.shape),test=list(terminal.shape),RUL=list(rul.shape))
    units={u:f[sensors].to_numpy() for u,f in train.groupby("unit")}
    for seed in (42,43,44):
        folder=DATA/f"out/A/{ds}_s{seed}"; tag=f"{ds}_s{seed}"
        split=read(folder/f"split_{tag}.json")
        perm=np.random.default_rng(seed).permutation(np.arange(1,101))
        assert split==dict(train70=perm[:70].tolist(),val15=perm[70:85].tolist(),calib15=perm[85:].tolist())
        bounds=read(folder/f"fit_boundaries_{tag}.json")
        oof=pd.read_csv(folder/f"oof_{tag}.csv",float_precision="round_trip")
        cal=pd.read_csv(folder/f"calib_{tag}.csv",float_precision="round_trip")
        assert set(oof.engine)=={f"train:{u}" for u in split["train70"]}
        assert set(cal.engine)=={f"train:{u}" for u in split["calib15"]}
        assert not set(oof.engine)&set(cal.engine)
        for bound in bounds:
            us=bound["train_units"]; subset=train[train.unit.isin(us)][sensors]
            mu=subset.mean().to_numpy(); sd=subset.std(ddof=1).to_numpy()
            check("A_sensor_mean:"+tag+bound["split"],mu,bound["MU"])
            check("A_sensor_sd:"+tag+bound["split"],sd,bound["SD"])
            blocks=[]; t=np.arange(30)-14.5
            for u in us:
                # Independent vectorized all-window extraction, then per-window features.
                a=units[u]; w=np.lib.stride_tricks.sliding_window_view(a,30,axis=0).transpose(0,2,1)
                z=(w-mu)/np.where(sd>1e-12,sd,1)
                blocks.append(np.concatenate((z.mean(1),z.std(1),z[:,-1,:],
                    np.einsum("t,ntc->nc",t,z-z.mean(1)[:,None,:])/(t@t)),axis=1))
            sc=StandardScaler().fit(np.vstack(blocks))
            check("A_feature_mean:"+tag+bound["split"],sc.mean_,bound["scaler_mean"])
            check("A_feature_scale:"+tag+bound["split"],sc.scale_,bound["scaler_scale"])
            if bound["split"]!="final":
                fold=int(bound["split"][-1]); held=split["train70"][14*fold:14*(fold+1)]
                assert bound["heldout_units"]==held
                assert set(us)==set(split["train70"])-set(held)
                assert set(oof[oof.fold==fold].engine)=={f"train:{u}" for u in held}
            else: assert us==split["train70"]
            boundary_rows.append(dict(dataset=ds,seed=seed,split=bound["split"],n_train_units=len(us)))
        for path in folder.glob("test_*_st*.csv"):
            table=pd.read_csv(path,float_precision="round_trip")
            assert len(table)==2100 and set(table.engine)=={f"test:{u}" for u in range(1,101)}
            for _,f in table.groupby("scen"):
                u=f.engine.str.split(":").str[1].astype(int).to_numpy()
                check("A_test_target:"+tag,rul[u-1],f.y_raw)
print("A preprocessing and group boundaries completed",flush=True)

# B confidence intervals: explicitly sample 100 engines and expand all replicates.
# This avoids the delivered harmonic-number weighted-AURC implementation.
stored=pd.read_csv(DATA/"out/B/B_bootstrap_ci_representative.csv",float_precision="round_trip")
group=["dataset","predictor","head","scenario","target","mode","metric"]
stored=stored.set_index(group,verify_integrity=True)
boot=np.load(DATA/"out/B/B_bootstrap_engine_indices.npz",allow_pickle=False)
rng=np.random.default_rng(20261017)
indices={ds:boot[ds] for ds in ("FD001","FD003")}
for ds,idx in indices.items():
    assert idx.shape==(2000,100)
    check("B_boot_rng:"+ds,idx,rng.integers(0,100,size=(2000,100)))
accum={}
for path in sorted((DATA/"out/A").glob("*/test_*_st*.csv")):
    ds=path.name[5:10]; idx=indices[ds]
    table=pd.read_csv(path,float_precision="round_trip")
    predictors=[c[5:] for c in table if c.startswith("pred_")]
    for scen in ("clean","A_bias+4","B_bias+4"):
        f=table[table.scen==scen].copy()
        f=f.sort_values("engine",key=lambda x:x.str.split(":").str[1].astype(int))
        assert f.engine.tolist()==[f"test:{u}" for u in range(1,101)]
        keys=np.array([hashlib.sha256(v.encode()).hexdigest() for v in f.engine])
        for p in predictors:
            for h in ("H_log","H_sq","pred_only","fault_indicator"):
                order=np.lexsort((np.arange(100),keys,f[f"score_{p}_{h}"]))
                rank=np.empty(100,int); rank[order]=np.arange(100)
                expanded_order=np.take_along_axis(idx,np.argsort(rank[idx],axis=1,kind="stable"),axis=1)
                for target in ("uncapped","cap125"):
                    y=f.y_raw.to_numpy(); y=np.minimum(y,125) if target=="cap125" else y
                    e=f[f"pred_{p}"].to_numpy()-y; e2=e*e
                    phm=np.where(e<0,np.expm1(-e/13),np.expm1(e/10))
                    aurc=np.mean(np.cumsum(e2[expanded_order],axis=1)/np.arange(1,101),axis=1)
                    for mode,col in [("threshold",f"acc_{p}_{h}"),("fixed_k80",f"sel80_{p}_{h}")]:
                        mask=f[col].to_numpy().astype(bool)[idx]
                        k=mask.sum(axis=1); den=np.where(k>0,k,np.nan)
                        values=dict(rmse=np.sqrt((e2[idx]*mask).sum(1)/den),
                            mae=(np.abs(e[idx])*mask).sum(1)/den,
                            overest_gt20_rate=((e[idx]>20)*mask).sum(1)/den,
                            acceptance_ratio=k/100,
                            phm08_mean_per_accepted=(phm[idx]*mask).sum(1)/den,
                            phm08_sum=(phm[idx]*mask).sum(1),aurc_mse=aurc)
                        for metric,v in values.items():
                            accum.setdefault((ds,p,h,scen,target,mode,metric),[]).append(v)
    print("B intervals: processed",path.parent.name,path.stem.rsplit("_",1)[1],flush=True)
interval_rows=[]
for key,values in accum.items():
    assert len(values)==9
    mean=np.nanmean(np.stack(values),axis=0)
    row=stored.loc[key]
    check("B_ci_lower:"+str(key),np.nanpercentile(mean,2.5),row.ci95_lo)
    check("B_ci_upper:"+str(key),np.nanpercentile(mean,97.5),row.ci95_hi)
    check("B_valid_replicates:"+str(key),np.isfinite(mean).sum(),row.n_reps_valid)
    interval_rows.append(dict(zip(group,key),ci95_lo=float(np.nanpercentile(mean,2.5)),
        ci95_hi=float(np.nanpercentile(mean,97.5)),n_reps_valid=int(np.isfinite(mean).sum())))
assert len(accum)==len(stored)
report=dict(verified_at=datetime.now(timezone.utc).isoformat(),checks=checks,
    mismatches=len(failures),failures=failures,max_absolute_difference_by_type=maxdiff,
    max_scaled_difference_by_type=maxrelative,raw_shapes=raw_shapes,
    C_independent_refits=C_results,A_preprocessing_boundaries=boundary_rows,
    raw_file_sha256=raw_hashes,B_interval_rows_independently_reconstructed=len(accum),
    bootstrap_reps=2000,scope="Independent non-RUL model refits; raw sensor/feature moment reconstruction and engine/fold/target checks; explicit resampling reconstruction of B confidence intervals. No new C-MAPSS predictor fitting.")
(HERE/"deep_review.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
pd.DataFrame(interval_rows).to_csv(HERE/"independently_reconstructed_B_intervals.csv",index=False)
print(json.dumps({k:v for k,v in report.items() if k not in ("C_independent_refits","A_preprocessing_boundaries","raw_file_sha256")},indent=2))
assert not failures
