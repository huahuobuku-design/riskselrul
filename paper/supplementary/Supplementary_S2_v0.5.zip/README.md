# Supplement S2 — expanded software validation

This supplement accompanies the local RiskSelRUL SoftwareX manuscript revision v0.5.
The computational baseline is frozen RiskSelRUL 0.1.0. The separate accompanying
0.1.1.dev0 source candidate adds audit input guards and a generic-regression example.

## Files and actual execution

- `expanded/`: unchanged received protocol/configuration, six C-MAPSS fits (FD001/FD003;
  seeds 42/43/44; streams 9001/9002/9003), all per-engine tables, commands/logs,
  B diagnostic analyses, six non-RUL fits, and package/boundary checks.
- `verification/`: receipt hashes, local arithmetic checks, independent refits,
  preprocessing reconstruction and interval comparisons.
- `scripts/`: portable local checking scripts. They do not run received Bot scripts.
- `riskselrul-0.1.0-py3-none-any.whl`: frozen computational wheel, identical to the
  experiment input, SHA-256 d121e3dfe73838e229388bc026c844f48800f20589c3c835bc9f10fba463c2aa.

Grok executed the received experiments on Linux. Local review independently
recalculated saved metrics, refitted both non-RUL examples for all seeds, rebuilt
C-MAPSS fold preprocessing from original raw data, and explicitly resampled engines
to verify the representative conditional intervals. The current local review did
not refit C-MAPSS predictors. S1 retains the earlier selected-run validation.

## Install and check

Use a fresh environment with the accompanying source candidate and its training
extra, or the frozen wheel plus pandas, SciPy and scikit-learn. Python >=3.10 is
required. The numerical scripts use NumPy/pandas/scikit-learn; recorded execution
versions are in `expanded/logs/environment.json`.

```sh
python scripts/verify_s2.py
python scripts/recheck_tables.py
python scripts/recheck_intervals_and_refits.py --raw-data /path/to/CMAPSSData
```

The last command needs the six original NASA FD001/FD003 text files. Their hashes
must match `expanded/config.json`. Raw NASA files are not redistributed here.
Check the manifest before rerunning: recheck scripts overwrite their generated
verification reports with fresh timestamps and results.

To rerun the baseline fitting, install the frozen wheel and its training extra in
a separate environment, then use the six commands in the received JSON logs,
adapting only local paths. Scripts B/C describe the published arithmetic definitions;
review them before execution and use new output directories. A's Bash helper is
POSIX-specific; the documented `riskselrul reproduce` commands work on Windows too.

## Definitions and scope

Original and cap-125 targets are evaluated with the same predictions and decisions.
Each dataset has nine seed–stream combinations; metrics are computed for each
combination before equal averaging. B contains 36,288 point-estimate rows.
Discrete AURC-MSE averages retained MSE across k=1,...,n. NASA Score is reported
as a sum and per accepted engine; zero accepted errors are undefined. Random
expected MSE is distinct from an observed random-score ordering in the C examples.

The 2,000 bootstrap samples draw engine identifiers jointly across seeds, fault
streams and scenarios. Fitted models and accepted flags remain fixed. Intervals
are conditional and available for clean/A_bias+4/B_bias+4 only; all 21 scenarios
retain point estimates. Intervals quantify test-engine sampling, not model-refit
or new-dataset uncertainty. Existing datasets had been explored before this task.

The diabetes data are used as a general-regression software example. Friedman
data are synthetic. The two target scales are separate. No external human
adoption or independent laboratory execution is asserted.
