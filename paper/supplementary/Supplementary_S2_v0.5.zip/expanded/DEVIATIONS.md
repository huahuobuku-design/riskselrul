# DEVIATIONS / 解释性决定（未改动 PROTOCOL.md / config.json）
1. reproduce 实际 CLI 需 `--data-root data/raw --out out/A/D_sS`（config.json 已写入该模板；非偏离，仅记录）。
2. B 的 cap125：定义为目标值 min(y_raw,125)，预测值、分数、阈值、接受标记均不变（协议未指定是否截断预测）。
3. B 的 bootstrap 置信区间仅对代表场景 clean/A_bias+4/B_bias+4 计算（全部21场景的点估计都已在 B_equal_average.csv / B_per_combination.csv 中给出，未删除任何场景）。区间为条件区间：接受/选择标记固定，按发动机重采样（每数据集每次重复一套索引，跨 seed/stream/场景/预测器/评分头共享），B=2000，seed=20261017；某次重复中组合接受为空时对该组合 nanmean 跳过（本轮实际空接受组合数 = 0）。
4. C：随机对照分数用 np.random.default_rng(seed+10000)，先抽 cal 再抽 test（同一生成器连续抽取）。拆分用 default_rng(seed).permutation，KFold(5, shuffle=True, random_state=seed)。"OOF风险排序" 对照即为风险头分数（风险头用 OOF 残差训练）。
5. D：examples/01 固定 FD001/seed42/stream 9001 单流，与 A 中 FD001_s42（三流）不是同一命令，故实际单独运行一次（非复用 A）。
6. D 发现 audit 对 0 行测试表不报错（bug）；给出最小复现与补丁，补丁仅在临时副本上测试，冻结安装未修改。
