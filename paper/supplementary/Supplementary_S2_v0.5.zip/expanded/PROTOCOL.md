# SX-EXPAND-20261017 — 本轮扩展协议（冻结于新测试之前）

> 说明：本文件为本轮扩展协议，在启动任何新测试/拟合之前冻结。所用 NASA C-MAPSS FD001/FD003 数据及被测软件此前已被探索过；本冻结**不是预注册**，也不构成独立新测试集。以下为用户协议消息原文（逐字）。

---

【SX-EXPAND-20261017｜Codex｜用户明确要求补实验；仅本地完成，不发行、不投稿】

沿用这个“面向传感器的轻量化”Bot。上一任务 SX-VALIDATE 已验收，本轮是新任务，不能用旧输出冒充新运行。用户认为工作量不足，要求补完整实验和复用证据。先回报可用输入与ETA，随后直接执行，最长45分钟实际工作；尽快交可核验阶段成果。不要设置例行任务、GitHub操作、公开上传、联系第三人，不索取令牌，不删改旧结果。不要只写建议或报告“将运行”。

被测软件固定为你上一轮已收到并核验的 riskselrul-0.1.0-review.zip（SHA256 6d0ea062812ee03492dcb3d0000a0953eae678a692a383c3c0a2d84e3a16bc99，1,154,306 B），原 wheel SHA256 d121e3dfe73838e229388bc026c844f48800f20589c3c835bc9f10fba463c2aa。不要使用 GitHub main 的另一套1.0.0。若原附件不可读，请先报告，勿混装。你已有原NASA FD001文件；检查FD003，缺失时只从NASA官方或其原始文件公开镜像获取并核对包内哈希清单。所有数据、代码、配置、输出均另建 SX_EXPAND_20261017/；原代码不改，新增实验脚本单独放 scripts/。

执行前请先保存本消息为 PROTOCOL.md、写实验配置JSON并计算二者SHA256，先在回复中发出这两个哈希，然后再启动新测试。该冻结只是本轮扩展协议，旧数据已探索过，不伪称预注册/独立新测试集。不要为结果好看改方法、种子、场景或删失败项。

A. 完整原数据链：FD001、FD003 × seed42/43/44 × stream9001/9002/9003。用同一冻结0.1.0 reproduce，每个dataset/seed一条命令、--streams 9001 9002 9003 --bootstrap-reps 2000，共6次实际拟合、18个seed-stream组合；可最多两个并行CPU进程，每进程线程设1。对每个新输出运行 audit。四个主预测器和四个风险评分沿用冻结配置，同发动机、同故障流比较。留所有命令、stdout/stderr、退出码、elapsed、依赖版本、fit_boundaries/split、OOF/calib/test表、bootstrap原始汇总和文件哈希。包过大可拆分 numeric/ 和 logs/ 两个ZIP，但不能只交均值。

B. 新增通用诊断分析，不改预测值/阈值：从A的逐发动机表计算 uncapped 原目标和 cap=125 的敏感性对照；RMSE/MAE、严格高估>20率、实际接受比例、NASA PHM08不对称Score（e=pred-true；e<0为expm1(-e/13)，其余expm1(e/10)）。报告Score总和及每接受样本均值，空接受均值为null，禁止将少接受的总分直接当优势。另报离散AURC-MSE=mean_{k=1..n}(retained_MSE_k)，说明定义与单位，oracle仅事后参考。随机参照用expected MSE，不当作expected RMSE。阈值结果和固定k=80结果分开；固定k比较沿用相同预测器/场景/种子/流。汇总先逐组合算指标再等权平均；置信区间按发动机重采样，保留同一发动机跨场景/流相关性，不把18组合当1800独立发动机。保留全部严重故障，主文代表场景固定clean/A_bias+4/B_bias+4，不按结果挑选。

C. 非RUL复用示例（脚本只调用公开数组API，不改库）：用 sklearn 自带 load_diabetes(scaled=False) 的真实442行数据，及明确标注为合成的 make_friedman1(n_samples=1000,n_features=10,noise=1.0,random_state=20261017)。各seed42/43/44随机split60%fit、20%calibration、20%test，保存ID；训练集5折OOF，用折内StandardScaler+Ridge(alpha=1.0)主预测器；风险头为最终训练X加OOF预测 -> log1p(abs(OOF residual))的Ridge(alpha=1.0)，其StandardScaler仅fit训练行，绝不用训练内残差、cal/test标签或故障参数。最终主预测器仅在fit训练集拟合。校准只用calibration的X与预测分数（不看calibration误差），线性分位数q=0.8；阈值冻结后测test。对照同一预测器的OOF风险排序、独立随机分数(seed+10000)、prediction-only分数（主预测值，非测试误差），oracle仅离线参照。报告fixed-k=floor(.8*n_test)和threshold的接受数量、RMSE、MSE、AURC；返回cal/test逐行真实值/预测/分数/ID、fold split/preprocess记录和可重跑脚本。该任务是软件复用演示，不是临床结论，不声称风险头必胜。

D. 安装与用户路径：带真实参数执行 examples/01_train_and_evaluate.py；能否借A某个等价命令不重复拟合要按脚本实际行为判断，别把之前无参exit2算通过。检查wheel/sdist实际78 NPZ含ridge_coef/截距/缩放器/风险头参数（不是仅风险头），生成完整清单。用 pytest --cov 如可用输出有意义覆盖率及未覆盖模块；不以凑测试数量为目标。audit的0表拒绝行为、并列/空集/非法输入/标签无关排序尽量在现有实现基础上验证，发现bug给最小复现和补丁，不擅改冻结受测版本。不要把静态源码推测当已运行。

交付 SX_EXPAND_20261017_results.zip（如超限可拆包）：中文SUMMARY.md，冻结协议与配置/hash，scripts，逐行numeric输出，完整stdout/stderr/exit，环境与真实耗时，文件manifest和外部ZIP大小/SHA256。环境去除主机名/账号等标识。简明区分本轮实际执行、保存表重算、旧结果引用与未完成。先交已完成部分再说明剩余；不得用“全部成功”掩盖失败或预算内未完成。完成即停止并给可下载文件，别只回复确认。
