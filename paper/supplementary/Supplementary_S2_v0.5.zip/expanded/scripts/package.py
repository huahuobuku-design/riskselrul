"""Build delivery ZIPs (<20MB each) with joint manifest; SHA256SUMS excludes itself."""
import zipfile,hashlib,os,json,glob
R="/workspace/SX_EXPAND_20261017"; os.chdir(R); D="deliver"; os.makedirs(D,exist_ok=True)
def sha(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
core=["SUMMARY.md","PROTOCOL.md","config.json","freeze_hashes.txt","DEVIATIONS.md","data/SHA256_data.txt"]
core+=sorted(glob.glob("scripts/*"))+sorted(glob.glob("logs/*"))+[p for p in glob.glob("out/[BCD]/**",recursive=True) if os.path.isfile(p) and not p.startswith("out/D/example01")]
groups={"SX_EXPAND_20261017_results.zip":core,
        "SX_EXPAND_20261017_numeric_D_example01.zip":[p for p in glob.glob("out/D/example01_FD001_s42/**",recursive=True) if os.path.isfile(p)]}
for r in sorted(glob.glob("out/A/*")):
    groups[f"SX_EXPAND_20261017_numeric_A_{os.path.basename(r)}.zip"]=[p for p in glob.glob(r+"/**",recursive=True) if os.path.isfile(p)]
man=[]
for z,files in groups.items():
    for f in files: man.append(dict(zip=z,path=f,bytes=os.path.getsize(f),sha256=sha(f)))
json.dump(man,open("MANIFEST_files.json","w"),indent=0)
groups["SX_EXPAND_20261017_results.zip"].append("MANIFEST_files.json")
for z,files in groups.items():
    with zipfile.ZipFile(f"{D}/{z}","w",zipfile.ZIP_DEFLATED,compresslevel=9) as Z:
        for f in files: Z.write(f,f)
with open(f"{D}/SHA256SUMS","w") as o:
    for z in sorted(groups): o.write(f"{sha(f'{D}/{z}')}  {z}\n")
for z in sorted(groups): print(z,os.path.getsize(f"{D}/{z}"))
