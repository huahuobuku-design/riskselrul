#!/usr/bin/env python3
"""Usage: runlog.py NAME -- cmd...  ; writes logs/NAME.{stdout,stderr,json}"""
import sys,subprocess,time,json,os,datetime
name=sys.argv[1]; cmd=sys.argv[sys.argv.index('--')+1:]
L=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','logs'); os.makedirs(L,exist_ok=True)
st=datetime.datetime.now().astimezone().isoformat(); t=time.time()
with open(f'{L}/{name}.stdout','w') as o, open(f'{L}/{name}.stderr','w') as e:
    rc=subprocess.call(cmd,stdout=o,stderr=e)
el=time.time()-t
json.dump({"name":name,"cmd":cmd,"cwd":os.getcwd().replace(os.path.expanduser('~'),'~'),"start":st,"end":datetime.datetime.now().astimezone().isoformat(),"elapsed_s":round(el,3),"exit_code":rc},open(f'{L}/{name}.json','w'),indent=1)
sys.exit(rc)
