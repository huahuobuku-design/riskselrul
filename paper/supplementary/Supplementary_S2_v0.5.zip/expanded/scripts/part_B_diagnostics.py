"""Part B: diagnostics recomputed from Part A per-engine test tables (no change to predictions/thresholds/flags).
Targets: uncapped (y_raw) and cap125 (target=min(y_raw,125); predictions unchanged).
Selection modes: threshold (acc_* flags from frozen thresholds), fixed_k80 (sel80_* flags), full.
AURC-MSE = mean_{k=1..n} retained_MSE_k, units RUL^2 (cycles^2), order = package stable order
(score, sha256(engine id), index). Oracle AURC post-hoc only. random_expected_mse = full-sample MSE.
Aggregation: per (dataset,seed,stream,predictor,head,scenario) then equal-weight mean.
CI: engine-cluster bootstrap, B=2000, seed 20261017; one engine-index draw per dataset per rep shared
across seeds/streams/scenarios/predictors/heads; flags held fixed (conditional on frozen thresholds/selections).
Usage: part_B_diagnostics.py OUT_A OUT_B"""
import sys,glob,json,hashlib,os,numpy as np,pandas as pd
A,O=sys.argv[1],sys.argv[2]; os.makedirs(O,exist_ok=True)
B,BSEED=2000,20261017; REP=["clean","A_bias+4","B_bias+4"]
def phm(e): return np.where(e<0,np.expm1(-e/13),np.expm1(e/10))
files=sorted(glob.glob(f"{A}/*/test_*_st*.csv"))
rows=[]; boot_inputs={}
for f in files:
    t=pd.read_csv(f,float_precision="round_trip"); ds,s,st=os.path.basename(f)[5:-4].split("_"); s=int(s[1:]); st=int(st[2:])
    preds=[c[5:] for c in t.columns if c.startswith("pred_")]
    heads=sorted({c.split("_",3)[3] if False else None for c in []})
    for scen,fr in t.groupby("scen",sort=False):
        fr=fr.sort_values("engine",key=lambda x:x.str.split(":").str[1].astype(int))
        eng=fr.engine.to_numpy(); n=len(eng)
        keys=np.array([hashlib.sha256(str(v).encode()).hexdigest() for v in eng])
        for tgt in ("uncapped","cap125"):
            y=fr.y_raw.to_numpy(float); y=np.minimum(y,125) if tgt=="cap125" else y
            for p in preds:
                pr=fr[f"pred_{p}"].to_numpy(float); e=pr-y; e2=e**2
                for h in ("H_log","H_sq","pred_only","fault_indicator"):
                    sc=fr[f"score_{p}_{h}"].to_numpy(float)
                    order=np.lexsort((np.arange(n),keys,sc)); cum=np.cumsum(e2[order])/np.arange(1,n+1)
                    orc=np.cumsum(np.sort(e2))/np.arange(1,n+1)
                    base=dict(dataset=ds,seed=s,stream=st,predictor=p,head=h,scenario=scen,target=tgt,n=n,
                              aurc_mse=float(cum.mean()),oracle_aurc_mse_posthoc=float(orc.mean()),random_expected_mse=float(e2.mean()))
                    for mode,flag in (("full",np.ones(n,bool)),("threshold",fr[f"acc_{p}_{h}"].to_numpy().astype(bool)),("fixed_k80",fr[f"sel80_{p}_{h}"].to_numpy().astype(bool))):
                        k=int(flag.sum()); ea=e[flag]
                        r=dict(base,mode=mode,n_accepted=k,acceptance_ratio=k/n,
                               rmse=float(np.sqrt(np.mean(ea**2))) if k else None,mae=float(np.mean(np.abs(ea))) if k else None,
                               mse=float(np.mean(ea**2)) if k else None,overest_gt20_rate=float(np.mean(ea>20)) if k else None,
                               phm08_sum=float(phm(ea).sum()),phm08_mean_per_accepted=float(phm(ea).mean()) if k else None)
                        rows.append(r)
                        if scen in REP and mode!="full":
                            boot_inputs.setdefault((ds,p,h,scen,tgt,mode),[]).append((eng,e,flag,order))
L=pd.DataFrame(rows); L.to_csv(f"{O}/B_per_combination.csv",index=False)
met=["n_accepted","acceptance_ratio","rmse","mae","mse","overest_gt20_rate","phm08_sum","phm08_mean_per_accepted","aurc_mse","oracle_aurc_mse_posthoc","random_expected_mse"]
g=L.groupby(["dataset","predictor","head","scenario","target","mode"],sort=False)
agg=g[met].mean(); agg["n_combinations"]=g.size(); agg["n_combinations_with_empty_accept"]=g["rmse"].apply(lambda x:int(x.isna().sum()))
agg.reset_index().to_csv(f"{O}/B_equal_average.csv",index=False)
# bootstrap
rng=np.random.default_rng(BSEED); dsets=sorted(L.dataset.unique())
n_by={d:int(L[L.dataset==d].n.iloc[0]) for d in dsets}
IDX={d:rng.integers(0,n_by[d],size=(B,n_by[d])) for d in dsets}
CNT={d:np.stack([np.bincount(r,minlength=n_by[d]) for r in IDX[d]]) for d in dsets}
H=np.concatenate([[0],np.cumsum(1/np.arange(1,500))])
out=[]
for (ds,p,h,scen,tgt,mode),lst in boot_inputs.items():
    C=CNT[ds]; res={m:[] for m in ("rmse","mae","overest_gt20_rate","acceptance_ratio","phm08_mean_per_accepted","phm08_sum","aurc_mse")}
    for eng,e,flag,order in lst:
        e2=e**2; F=C*flag; k=F.sum(1); nk=np.where(k>0,k,np.nan)
        res["rmse"].append(np.sqrt((F*e2).sum(1)/nk)); res["mae"].append((F*np.abs(e)).sum(1)/nk)
        res["overest_gt20_rate"].append((F*(e>20)).sum(1)/nk); res["acceptance_ratio"].append(k/C.sum(1))
        res["phm08_sum"].append((F*phm(e)).sum(1)); res["phm08_mean_per_accepted"].append((F*phm(e)).sum(1)/nk)
        Co=C[:,order]; eo=e2[order]; K=np.cumsum(Co,1)-Co; S=np.cumsum(Co*eo,1)-Co*eo
        tot=(Co*eo+(S-K*eo)*(H[K+Co]-H[K])).sum(1)/C.sum(1); res["aurc_mse"].append(tot)
    for m,v in res.items():
        v=np.nanmean(np.stack(v),0) if m!="acceptance_ratio" else np.mean(np.stack(v),0)
        point=agg.loc[(ds,p,h,scen,tgt,mode)]
        point = point["aurc_mse"] if m=="aurc_mse" else point[m]
        out.append(dict(dataset=ds,predictor=p,head=h,scenario=scen,target=tgt,mode=mode,metric=m,point_equal_avg=None if pd.isna(point) else float(point),
            ci95_lo=float(np.nanpercentile(v,2.5)),ci95_hi=float(np.nanpercentile(v,97.5)),n_reps_valid=int(np.isfinite(v).sum())))
pd.DataFrame(out).to_csv(f"{O}/B_bootstrap_ci_representative.csv",index=False)
np.savez_compressed(f"{O}/B_bootstrap_engine_indices.npz",**{d:IDX[d] for d in dsets})
json.dump(dict(B=B,seed=BSEED,files=[os.path.relpath(f) for f in files],n_rows=len(L),representative=REP,
  note="nanmean over combinations with empty acceptance inside a rep; point = equal average over seed-stream combos"),open(f"{O}/B_meta.json","w"),indent=1)
print("rows",len(L),"files",len(files))
