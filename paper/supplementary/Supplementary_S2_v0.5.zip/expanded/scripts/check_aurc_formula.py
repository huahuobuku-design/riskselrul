"""Check closed-form weighted AURC used in Part B bootstrap against explicit expansion + package curve."""
import numpy as np
from riskselrul import risk_coverage_curve
rng=np.random.default_rng(1);n=30;e2=rng.random(n)*100;sc=rng.random(n);order=np.argsort(sc)
H=np.concatenate([[0],np.cumsum(1/np.arange(1,500))]);ok=True
C=np.ones(n,int);Co=C[order];eo=e2[order];K=np.cumsum(Co)-Co;S=np.cumsum(Co*eo)-Co*eo
v=(Co*eo+(S-K*eo)*(H[K+Co]-H[K])).sum()/n; ref=np.mean([r["retained_mse"] for r in risk_coverage_curve(np.sqrt(e2),np.zeros(n),sc)])
print("identity",v,ref); ok&=np.isclose(v,ref)
C=rng.integers(0,4,n);Co=C[order];K=np.cumsum(Co)-Co;S=np.cumsum(Co*eo)-Co*eo
v=(Co*eo+(S-K*eo)*(H[K+Co]-H[K])).sum()/C.sum(); x=np.repeat(eo,Co); ref=np.mean(np.cumsum(x)/np.arange(1,len(x)+1))
print("weighted",v,ref); ok&=np.isclose(v,ref); print("PASS" if ok else "FAIL")
