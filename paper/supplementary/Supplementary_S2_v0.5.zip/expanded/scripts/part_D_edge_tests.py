"""Edge-case checks via public API. Usage: part_D_edge_tests.py A_RUN_DIR. Copies run to temp; never modifies originals."""
import sys,json,shutil,tempfile,pathlib,numpy as np,pandas as pd
from riskselrul import calibrate_threshold,fixed_k_metrics,prediction_metrics,risk_coverage_curve
from riskselrul.audit import audit_run
R=[]
def case(name,fn,expect):
    try: out=fn(); res=("ok",repr(out)[:300])
    except Exception as e: res=("raise",f"{type(e).__name__}: {e}"[:300])
    R.append(dict(case=name,expected=expect,observed=res[0],detail=res[1],matches_expectation=(res[0]==expect)))
p=np.array([10.,20,30,40]);y=np.array([12.,18,35,40])
case("pm_empty",lambda:prediction_metrics([],[]),"ok")
case("pm_nan",lambda:prediction_metrics([np.nan],[1]),"raise")
case("pm_len_mismatch",lambda:prediction_metrics([1,2],[1]),"raise")
case("pm_2d",lambda:prediction_metrics([[1]],[[1]]),"raise")
case("cal_empty",lambda:calibrate_threshold([]),"raise")
case("cal_rate0",lambda:calibrate_threshold([1,2],0),"raise")
case("cal_rate_gt1",lambda:calibrate_threshold([1,2],1.5),"raise")
case("fk_k0_emptyset",lambda:fixed_k_metrics(p,y,[1,2,3,4],0),"ok")
case("fk_k_gt_n",lambda:fixed_k_metrics(p,y,[1,2,3,4],5),"raise")
case("fk_k_float",lambda:fixed_k_metrics(p,y,[1,2,3,4],2.0),"raise")
case("fk_k_bool",lambda:fixed_k_metrics(p,y,[1,2,3,4],True),"raise")
case("fk_inf_score",lambda:fixed_k_metrics(p,y,[1,np.inf,3,4],2),"raise")
case("curve_empty",lambda:risk_coverage_curve([],[],[]),"ok")
# ties: deterministic, by sha256(id) then index
t1=fixed_k_metrics(p,y,[1,1,1,1],2,["a","b","c","d"])["selected_indices"]
t2=fixed_k_metrics(p,y,[1,1,1,1],2,["a","b","c","d"])["selected_indices"]
R.append(dict(case="ties_deterministic",observed=str(t1),matches_expectation=t1==t2))
# label independence: selection identical when targets change
rng=np.random.default_rng(0); s=rng.random(50); pp=rng.random(50)*100
a=fixed_k_metrics(pp,rng.random(50)*100,s,30)["selected_indices"]; b=fixed_k_metrics(pp,rng.random(50)*100+500,s,30)["selected_indices"]
R.append(dict(case="label_independent_order_fixed_k",matches_expectation=a==b))
ca=[r["k"] for r in risk_coverage_curve(pp,pp*0,s)]; R.append(dict(case="curve_k_1_to_n",matches_expectation=ca==list(range(1,51))))
# audit edge cases on copy of a real run
if len(sys.argv)>1:
    src=pathlib.Path(sys.argv[1])
    def mk(mut):
        d=pathlib.Path(tempfile.mkdtemp())/"run"; shutil.copytree(src,d); mut(d); return d
    def empty_metrics(d):
        m=pd.read_csv(d/"metrics_long.csv"); m.iloc[:0].to_csv(d/"metrics_long.csv",index=False)
    def empty_test(d):
        for f in d.glob("test_*_st*.csv"): pd.read_csv(f).iloc[:0].to_csv(f,index=False)
    def no_tables(d):
        for f in d.glob("test_*_st*.csv"): f.unlink()
    def tamper(d):
        m=pd.read_csv(d/"metrics_long.csv",float_precision="round_trip"); m.loc[0,"full.MSE"]+=1; m.to_csv(d/"metrics_long.csv",index=False)
    def dup_engine(d):
        f=sorted(d.glob("test_*_st*.csv"))[0]; t=pd.read_csv(f,float_precision="round_trip"); pd.concat([t,t.iloc[:1]]).to_csv(f,index=False)
    case("audit_unmodified_copy",lambda:audit_run(mk(lambda d:None))[0]["mismatches"],"ok")
    case("audit_empty_metrics",lambda:audit_run(mk(empty_metrics)),"raise")
    case("audit_no_test_tables",lambda:audit_run(mk(no_tables)),"raise")
    case("audit_zero_row_test_tables",lambda:audit_run(mk(empty_test)),"raise")
    case("audit_tampered_metric_detected",lambda:(lambda r:r["mismatches"]>0 or (_ for _ in ()).throw(AssertionError("not detected")))(audit_run(mk(tamper))[0]),"ok")
    case("audit_duplicate_engine",lambda:audit_run(mk(dup_engine)),"raise")
json.dump(R,open("out/D/edge_tests.json","w"),indent=1)
for r in R: print(r["case"],r.get("observed"),"MATCH" if r["matches_expectation"] else "MISMATCH",r.get("detail","")[:120])
