#!/bin/bash
# Part A: 6 reproduce + audit, max 2 parallel, threads=1
cd "$(dirname "$0")/.."
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
one(){ D=$1; S=$2; O=out/A/${D}_s${S}
  python3 scripts/runlog.py A_reproduce_${D}_s${S} -- venv/bin/riskselrul reproduce --data-root data/raw --dataset $D --seed $S --streams 9001 9002 9003 --bootstrap-reps 2000 --out $O
  python3 scripts/runlog.py A_audit_${D}_s${S} -- venv/bin/riskselrul audit --run $O; }
(one FD001 42; one FD001 43; one FD001 44) &
(one FD003 42; one FD003 43; one FD003 44) &
wait; echo ALLDONE
