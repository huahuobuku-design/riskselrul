"""Inventory NPZ files in wheel and sdist (allow_pickle=False)."""
import zipfile,tarfile,io,json,hashlib,sys,numpy as np,collections
W="input/riskselrul-0.1.0/dist/riskselrul-0.1.0-py3-none-any.whl"; S="input/riskselrul-0.1.0/dist/riskselrul-0.1.0.tar.gz"
def entries():
    z=zipfile.ZipFile(W)
    for n in z.namelist():
        if n.endswith(".npz"): yield "wheel",n,z.read(n)
    t=tarfile.open(S)
    for m in t.getmembers():
        if m.name.endswith(".npz"): yield "sdist",m.name,t.extractfile(m).read()
rows=[];cnt=collections.Counter();keyunion=collections.Counter()
for src,n,b in entries():
    d=np.load(io.BytesIO(b),allow_pickle=False)
    ks={k:dict(shape=list(d[k].shape),dtype=str(d[k].dtype)) for k in d.files}
    cnt[src]+=1; keyunion.update((src,k) for k in d.files)
    rows.append(dict(source=src,path=n,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),keys=ks))
req=["ridge_coef","intercept","scaler","risk"]
summ={s:dict(count=cnt[s],keys={k:c for (ss,k),c in keyunion.items() if ss==s}) for s in cnt}
for s in summ:
    files=[r for r in rows if r["source"]==s]
    summ[s]["files_with_substring"]={q:sum(any(q in k for k in r["keys"]) for r in files) for q in req}
json.dump(dict(summary=summ,files=rows),open("out/D/npz_manifest.json","w"),indent=1)
print(json.dumps(summ,indent=1))
