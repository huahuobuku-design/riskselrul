# SX-EXPAND-20261017 结果摘要（中文）

被测软件：riskselrul 0.1.0（zip SHA256 6d0ea062…16bc99，1,154,306 B；wheel SHA256 d121e3df…63c2aa，已逐字节核验）。未使用 GitHub 1.0.0，未修改受测代码。
冻结：PROTOCOL.md SHA256 1ba9d383d848be84dffebdfc727d9cf5ecbda52654a566b0c7cdce50904210a3；config.json SHA256 34a0d17032e6ed5e98499b5ec14735e72bd2b9f2285fc18ec16e95070e637a3f（新测试前冻结；非预注册，数据此前已被探索）。偏离与解释见 DEVIATIONS.md。
环境：新建 venv（Python 3.13.5，Linux），numpy 2.5.4 / pandas 3.0.6 / scipy 1.18.1 / scikit-learn 1.9.1，线程=1，最多2并行进程；logs/environment.json、logs/pip_freeze.txt（已去除主机名/账号）。
数据：FD001/FD003 train/test/RUL 六个文件复制到 data/raw 并重新计算哈希，全部与包内 data_manifest.json 一致（data/SHA256_data.txt）；未下载任何数据。

## 一、本轮实际执行（含命令日志 logs/*.json/.stdout/.stderr：cmd、起止时间、elapsed、退出码）
**A. 完整原数据链**：6 次 `riskselrul reproduce`（FD001/FD003 × seed 42/43/44，--streams 9001 9002 9003 --bootstrap-reps 2000），18 个 seed-stream 组合。全部 exit 0，单次 elapsed 117.8–122.9 s（2 进程并行，总墙钟约 6 min）。6 次 audit 全部 exit 0，每次 checked=16176，mismatches=0。输出（split、fit_boundaries、OOF/calib/test 逐发动机表、thresholds、metrics_long、bootstrap 汇总 metrics_avg_combos、manifest）全部保留在 out/A/。
**B. 通用诊断（由 A 保存的逐发动机表重算，不改预测/阈值/接受标记）**：out/B/。B_per_combination.csv（36288 行 = 2 数据集×9组合×21场景×4预测器×4评分头×2目标×3模式），B_equal_average.csv（逐组合后等权平均），B_bootstrap_ci_representative.csv（代表场景 clean/A_bias+4/B_bias+4，发动机簇 bootstrap B=2000, seed=20261017，共享索引，条件区间），B_bootstrap_engine_indices.npz。指标：RMSE/MAE/MSE、严格高估>20率、接受比例、PHM08 Score 总和及每接受样本均值（空=null；本轮空接受组合数为0）、AURC-MSE=mean_{k=1..n} retained_MSE_k（单位 RUL²=cycles²）、oracle AURC（仅事后参照）、随机参照 expected MSE（=全样本 MSE，不是 RMSE）。阈值与固定 k=80 分开报告。uncapped 与 cap125（仅截断目标）两套。AURC 加权闭式公式经 scripts/check_aurc_formula.py 与包内曲线对照 PASS。
  - 代表值（ridge_aug，uncapped，阈值模式，等权平均 [95% 发动机 bootstrap CI]）：FD001 clean RMSE：H_log 17.20 [14.85,19.60]、pred_only 17.00；AURC-MSE：H_log 237.3 [169.0,320.9]、H_sq 265.2、pred_only 223.1、fault_indicator 353.7；随机期望 MSE 293.5；oracle 69.8。FD003 clean AURC-MSE：H_log 220.2 [162.4,292.8]、H_sq 269.7、pred_only 249.2、fault_indicator 341.1。
  - B_bias+4 下 ridge_aug 误差很大（FD001 阈值 RMSE 82.8–128.4；FD003 72.5–75.0），已如实保留，未剔除。风险头并非在所有场景/预测器下占优（例如 FD001 clean 时 pred_only 的 AURC 低于 H_log）。
**C. 非 RUL 复用**（scripts/part_C_reuse.py，只调用 calibrate_threshold/fixed_k_metrics/prediction_metrics/risk_coverage_curve 公开 API）：diabetes（真实，442 行，scaled=False）与 friedman1（**合成**）× seed 42/43/44，60/20/20 拆分，5 折 OOF，风险头仅用 OOF 残差，标定只用 cal 分数（q=0.8 linear）。逐行 cal/test/oof CSV、split/fold/scaler/系数记录在 out/C/。AURC-MSE（风险头 / 随机 / prediction-only / oracle）：diabetes s42 1908/3369/1944/716，s43 2280/3018/2047/726，s44 2124/2771/2688/783；friedman1 s42 5.5/6.4/5.5/1.7，s43 5.3/10.2/5.3/1.6，s44 4.8/5.9/5.0/1.4。阈值接受数在 cal 校准后 test 上波动（diabetes 55–75/89）。仅为软件复用演示，非临床结论，不声称风险头必胜（diabetes s43 上 prediction-only AURC 更低）。
**D. 安装与用户路径**：
  - examples/01_train_and_evaluate.py 带真实参数（--data-root data/raw --out out/D/example01_FD001_s42）运行：exit 0，77.6 s，REPRODUCTION_PASS，内置 audit checked=5392 mismatches=0；单独 audit 也 0 mismatch。该脚本固定 FD001/seed42/仅 stream 9001，与 A 的三流命令不同，因此实际单独运行，未借用 A。
  - NPZ 清单 out/D/npz_manifest.json：wheel 78 个 NPZ，每个都含 scaler_mean/scaler_scale、ridge_coef/ridge_intercept、risk_mean/risk_scale/risk_coef/risk_intercept、raw_MU/raw_SD/raw_MU21、indices、threshold_*（不只是风险头）。sdist 79 个 = 同样 78 个 + 1 个 golden fixture（raw/predictions/risks/accepted…）。allow_pickle=False 读取。
  - pytest --cov（包自带 18 个测试）：18 passed；总覆盖率 40%。未覆盖：cli.py 0%、pipeline.py 0%、_legacy/train_entry.py 0%、_legacy/bootstrap.py 0%、_legacy/data.py 0%、__main__.py 0%；data.py 72%、faults 74%、metrics 91%、deploy 92%、audit 95%（out/D/coverage.json）。注意：cli/pipeline 实际在 A/D 运行中被执行，只是不在 pytest 覆盖内。
  - 边界测试（scripts/part_D_edge_tests.py，实际执行，out/D/edge_tests.json）：22 项中 21 项符合预期（非法输入/NaN/长度不符/2D/空校准/acceptance_rate 越界/k 越界/非整数/bool/inf 全部拒绝；空集 k=0 与空曲线返回 None/[]；并列确定性；标签无关排序；audit 拒绝空 metrics、无测试表、重复发动机；篡改 metric 被检出）。
  - **发现 bug**：audit 对 0 行（只有表头）的测试表**不报错**，返回 checked=48、mismatches=0。最小复现 out/D/bug_audit_zero_rows/repro.py；补丁 audit_zero_rows.patch；在临时副本上测试补丁：0 行被拒绝，真实运行仍 0 mismatch（test_patch.py，日志 D_bug_patch_test）。冻结安装未修改。

## 二、保存表重算
B 全部数值来自 A 本轮新生成的 test_*_st*.csv；C、D 为本轮实际运行。

## 三、旧结果引用
无。未使用 /workspace/sx_validate、wp05a 等旧输出（旧 venv 只在冻结阶段看过 --help）。

## 四、未完成 / 限制
- B 的 bootstrap CI 只对代表场景计算（其余场景只有点估计）。
- 补丁只在临时副本上测试，未进入受测版本。
- pytest 覆盖率不包含 CLI/pipeline 的端到端运行。
