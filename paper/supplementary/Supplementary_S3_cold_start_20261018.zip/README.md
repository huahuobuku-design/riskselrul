# Fresh-runner and local execution records

Code commit: 5a90e3140d8d9c0610b7e8f6a7121d0f6277fb32. GitHub Actions run: 39124409463.
FD001 and FD003, seed 42 / stream 9001, 2,000 bootstrap replicates.
Each remote and local run performed a fresh NASA-hosted download, strict input
hash checking, complete training and arithmetic auditing. Original NASA files
and downloaded ZIPs are deliberately not redistributed here.

Install the code at the pinned commit with its train extra. Recompute a saved
run with `python -m riskselrul audit --run remote/cold-start-FD001/run` (or any
other run folder). To rebuild the additional checks, obtain and extract the
NASA files, then run `python review_execution.py --data-root PATH_TO_RAW_FILES`
from the extracted supplement. This writes a new execution_review.json; keep
the manifest copy before modifying any file. The checker verifies output
hashes, original data hashes recorded in inspection, selected metrics,
calibration quantiles, fold disjointness, and fold sensor statistics.

Platform fits are NOT numerically identical. The review JSON separately reports
point predictions, risk scores, acceptance flags and metric differences.
Ridge predictions differ by at most 1.61e-11; augmented HGB predictions differ
by up to 10.17 cycles. Maximum accepted-count difference is ten engines.
Neither the numerical equivalence of fits nor a new performance advantage is claimed.
The frozen article result tables and figure remain sourced from S2.

Public logs replace local machine path prefixes with WORKSPACE. Original/public hashes of edited metadata/log files are in path_redaction_record.json. Per-run hash lists refer to the public files. Numerical CSV files are byte-identical to the execution outputs.
