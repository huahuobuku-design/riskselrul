"""Recompute delivered numeric evidence independently of training imports."""
import hashlib
import argparse
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
CONFIG_PATH = HERE/'config.json'
if not CONFIG_PATH.exists():
    CONFIG_PATH = HERE.parent/'github_softwarex_dev/src/riskselrul/_legacy/config.json'
CONFIG = json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
SENSOR_COLS = [4+int(s[1:]) for s in CONFIG['features']['sensors']]


def review(folder, dataset, raw_root):
    manifest = json.loads((folder/'cold_start_manifest.json').read_text())
    assert manifest['status'] == 'PASS'
    assert all(c['exitcode'] == 0 for c in manifest['commands'])
    run = folder/'run'
    hashes = json.loads((run/'output_hashes.json').read_text())
    for name, digest in hashes.items():
        assert hashlib.sha256((run/name).read_bytes()).hexdigest() == digest, name
    assert (run/'train.exitcode.txt').read_text().strip() == '0'
    audit = json.loads((run/'audit.json').read_text())
    assert audit['mismatches'] == 0
    data = json.loads((folder/'01.stdout.log').read_text())
    assert all(x['matches_archived_bytes'] for x in data['files'])
    raw = np.loadtxt(raw_root/f'train_{dataset}.txt')
    bounds = json.loads((run/f'fit_boundaries_{dataset}_s42.json').read_text())
    split = json.loads((run/f'split_{dataset}_s42.json').read_text())
    training = set(split['train70'])
    calibration = set(split['calib15'])
    assert len(training) == 70 and len(calibration) == 15
    assert not training & calibration
    assert not training & set(split['val15'])
    max_mu = max_sd = 0.
    for b in bounds:
        fitting = set(b['train_units'])
        assert fitting <= training and not fitting & calibration
        assert not fitting & set(b.get('heldout_units', []))
        values = raw[np.isin(raw[:, 0], list(fitting))][:, SENSOR_COLS]
        mu, sd = values.mean(axis=0), values.std(axis=0, ddof=1)
        np.testing.assert_allclose(mu, b['MU'], rtol=1e-10, atol=1e-10)
        np.testing.assert_allclose(sd, b['SD'], rtol=1e-10, atol=1e-10)
        max_mu = max(max_mu, float(np.max(np.abs(mu-b['MU']))))
        max_sd = max(max_sd, float(np.max(np.abs(sd-b['SD']))))
    oof = pd.read_csv(run/f'oof_{dataset}_s42.csv', float_precision='round_trip')
    for engine, fold, units in zip(oof.engine, oof.fold, oof.fold_train_units):
        unit = int(engine.split(':')[1])
        assert unit not in json.loads(units)
        assert unit in bounds[int(fold)]['heldout_units']
    cal = pd.read_csv(run/f'calib_{dataset}_s42.csv', float_precision='round_trip')
    assert {int(x.split(':')[1]) for x in cal.engine} == calibration
    thresholds = json.loads((run/f'thresholds_{dataset}_s42.json').read_text())
    test = pd.read_csv(run/f'test_{dataset}_s42_st9001.csv', float_precision='round_trip')
    metrics = pd.read_csv(run/'metrics_long.csv', float_precision='round_trip')
    assert len(test) == 2100 and test.scen.nunique() == 21
    numeric_checks = 0
    for prediction, heads in thresholds.items():
        for head, threshold in heads.items():
            name = f'{prediction}_{head}'
            np.testing.assert_allclose(np.quantile(cal[f'score_{name}'], .8), threshold, rtol=1e-12)
            numeric_checks += 1
            for scenario, rows in test.groupby('scen', sort=False):
                rows = rows.reset_index(drop=True)
                accepted = rows[f'score_{name}'].to_numpy() <= threshold
                assert np.array_equal(accepted, rows[f'acc_{name}'].to_numpy().astype(bool))
                order = sorted(range(len(rows)), key=lambda i: (
                    rows[f'score_{name}'].iloc[i],
                    hashlib.sha256(str(rows.engine.iloc[i]).encode()).hexdigest(),
                    int(rows.draw.iloc[i])))
                selected = np.zeros(len(rows), dtype=bool)
                selected[order[:80]] = True
                assert np.array_equal(selected, rows[f'sel80_{name}'].to_numpy().astype(bool))
                error = rows[f'pred_{prediction}'].to_numpy()-rows.y_raw.to_numpy()
                record = metrics[(metrics.pred == prediction)&(metrics['head'] == head)&(metrics.scen == scenario)].iloc[0]
                assert int(record['thr.k']) == int(accepted.sum())
                for mask, col in [(np.ones(len(rows),dtype=bool),'full.MSE'), (selected,'k80.sel.MSE'), (accepted,'thr.ret_MSE')]:
                    if mask.any():
                        np.testing.assert_allclose(np.mean(error[mask]**2), record[col], rtol=1e-10, atol=1e-10)
                    else:
                        assert pd.isna(record[col])
                    numeric_checks += 1
    return dict(status='PASS', dataset=dataset, seed=42, stream=9001, bootstrap_reps=2000,
                files_hashed=len(hashes), package_audit_checks=audit['checked'],
                independent_scalar_metric_checks=numeric_checks,
                oof_rows_checked=len(oof), fold_and_final_records=len(bounds),
                max_sensor_mean_difference=max_mu, max_sensor_sd_difference=max_sd,
                test_rows=len(test), raw_training_seconds=manifest['commands'][2]['seconds'],
                versions=json.loads((run/'package_run_manifest.json').read_text())['versions'])


def compare(dataset):
    name=f'test_{dataset}_s42_st9001.csv'
    a=pd.read_csv(HERE/f'remote/cold-start-{dataset}/run'/name, float_precision='round_trip').set_index(['engine','draw','scen']).sort_index()
    b=pd.read_csv(HERE/f'local_{dataset}/run'/name, float_precision='round_trip').set_index(['engine','draw','scen']).sort_index()
    assert a.index.equals(b.index)
    result={}
    for prefix in ['pred_', 'score_', 'acc_', 'sel80_']:
        cols=[c for c in a if c.startswith(prefix)]
        left,right=a[cols].to_numpy(),b[cols].to_numpy()
        result[prefix]=dict(values=left.size, exact_differences=int(np.count_nonzero(left != right)),
                           max_absolute_difference=float(np.max(np.abs(left-right))))
    per_predictor={}
    for predictor in ['ridge_clean','ridge_aug','hgb_clean','hgb_aug']:
        column=f'pred_{predictor}'
        diff=np.abs(a[column].to_numpy()-b[column].to_numpy())
        per_predictor[predictor]=dict(max_prediction_difference=float(diff.max()),
                                      prediction_differences_over_1e_8=int((diff>1e-8).sum()))
    metric_name='metrics_long.csv'
    keys=['ds','seed','stream','pred','head','scen']
    ma=pd.read_csv(HERE/f'remote/cold-start-{dataset}/run'/metric_name,float_precision='round_trip').set_index(keys).sort_index()
    mb=pd.read_csv(HERE/f'local_{dataset}/run'/metric_name,float_precision='round_trip').set_index(keys).sort_index()
    metric_summary={}
    for column in ['thr.k','thr.ret_RMSE','k80.sel.RMSE']:
        delta=(ma[column]-mb[column]).dropna()
        metric_summary[column]=dict(compared_cells=len(delta),max_absolute_difference=float(delta.abs().max()))
    return dict(dataset=dataset, matched_rows=len(a), comparisons=result,
                per_predictor=per_predictor, metric_differences=metric_summary,
                interpretation='Platform-specific fits compared descriptively; no cross-platform bitwise requirement')


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--remote-only', action='store_true')
    parser.add_argument('--data-root', type=Path, default=HERE/'local_FD001/data')
    args=parser.parse_args()
    scopes=['remote'] if args.remote_only else ['remote','local']
    records=[]
    for scope in scopes:
        for ds in ['FD001','FD003']:
            folder=HERE/f'remote/cold-start-{ds}' if scope=='remote' else HERE/f'local_{ds}'
            records.append(dict(scope=scope, **review(folder, ds, args.data_root)))
    report=dict(status='PASS', records=records,
                scope='Received files, hashes, selected metric recomputation, recorded fold disjointness and independently rebuilt sensor statistics; not a proof of every possible leakage path')
    if len(scopes)==2:
        report['cross_platform']=[compare(ds) for ds in ['FD001','FD003']]
    filename='remote_numeric_review.json' if len(scopes)==1 else 'execution_review.json'
    (HERE/filename).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))
